import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import { run, get, query } from './database.js';

const router = express.Router();
const SECRET = 'dev-secret-key-change-in-prod';

// Middleware to verify token
const auth = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'No token provided' });

    jwt.verify(token, SECRET, (err, decoded) => {
        if (err) return res.status(401).json({ error: 'Invalid token' });
        req.user = decoded;
        next();
    });
};

// --- AUTH ---
router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await get('SELECT * FROM profiles WHERE email = ?', [email]);
        if (!user) return res.status(400).json({ error: 'User not found' });

        const valid = await bcrypt.compare(password, user.password_hash);
        if (!valid) return res.status(400).json({ error: 'Invalid password' });

        const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, SECRET, { expiresIn: '24h' });
        res.json({ session: { access_token: token, user: { id: user.id, email: user.email, role: user.role } } });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/signup', async (req, res) => {
    const { email, password, data } = req.body;
    try {
        const existing = await get('SELECT * FROM profiles WHERE email = ?', [email]);
        if (existing) return res.status(400).json({ error: 'Email already registered' });

        const id = uuidv4();
        const hash = await bcrypt.hash(password, 10);

        // Insert into profiles
        await run(`INSERT INTO profiles (id, email, password_hash, first_name, last_name, role, active, join_date) 
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [id, email, hash, data.first_name, data.last_name, data.role || 'Miembro', 1, new Date().toISOString()]);

        const token = jwt.sign({ id, email, role: data.role }, SECRET, { expiresIn: '24h' });
        res.json({ session: { access_token: token, user: { id, email, role: data.role } } });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.get('/profile/:id', auth, async (req, res) => {
    try {
        const user = await get('SELECT * FROM profiles WHERE id = ?', [req.params.id]);
        if (user) delete user.password_hash;
        res.json(user);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- PROFILES / MEMBERS ---
router.get('/profiles', auth, async (req, res) => {
    try {
        const users = await query(`
            SELECT p.*,
            (SELECT COUNT(*) FROM consolidation_steps WHERE profile_id = p.id) as total_steps,
            (SELECT COUNT(*) FROM consolidation_steps WHERE profile_id = p.id AND completed = 1) as completed_steps
            FROM profiles p
            ORDER BY first_name
        `);
        users.forEach(u => delete u.password_hash);
        res.json(users);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- CONSOLIDATION STEPS HANDLING ---

const CONSOLIDATION_STEPS_TEMPLATE = [
    'Asignar distrito y célula',
    'Llamada y programación de cita',
    'Visita de vínculo',
    'Tema 1',
    'Tema 2',
    'Tema 3',
    'Tema 4',
    'Tema 5',
    'Tema 6',
    'Tema 7',
    'Asistir a célula',
    'Encuentro',
    'Bautizo'
];

// ... imports assumed to be correct

router.get('/profiles/:id/steps', auth, async (req, res) => {
    try {
        const profileId = req.params.id;
        console.log(`[GET STEPS] Fetching steps for profile: ${profileId}`);

        let steps = await query('SELECT * FROM consolidation_steps WHERE profile_id = ? ORDER BY step_order', [profileId]);
        console.log(`[GET STEPS] Found ${steps.length} existing steps.`);

        // Self-healing: If no steps found, check if profile is a consolidation candidate and generate them
        if (steps.length === 0) {
            const profile = await get('SELECT consolidation_stage_id FROM profiles WHERE id = ?', [profileId]);
            console.log(`[GET STEPS] Profile found:`, profile);

            // Trigger generation if profile exists. 
            // We relax the check: even if consolidation_stage_id is falsy, if they are calling this endpoint, 
            // it's likely from the consolidation board context. 
            // However, to be safe, we'll try to update the profile to a default stage if needed? 
            // No, let's just generate steps if we can confirm it's a "User" that should have them. 
            // For now, keep the stage check but log why it might fail.

            if (profile && profile.consolidation_stage_id) {
                console.log(`[GET STEPS] Auto-generating steps for ${profileId}`);
                for (let i = 0; i < CONSOLIDATION_STEPS_TEMPLATE.length; i++) {
                    const stepId = uuidv4();
                    await run('INSERT INTO consolidation_steps (id, profile_id, step_name, step_order) VALUES (?, ?, ?, ?)',
                        [stepId, profileId, CONSOLIDATION_STEPS_TEMPLATE[i], i]);
                }
                // Fetch again
                steps = await query('SELECT * FROM consolidation_steps WHERE profile_id = ? ORDER BY step_order', [profileId]);
                console.log(`[GET STEPS] Steps generated. Count: ${steps.length}`);
            } else {
                console.log(`[GET STEPS] Skipped generation. Stage ID: ${profile?.consolidation_stage_id}`);
            }
        }

        res.json(steps);
    } catch (err) {
        console.error('[GET STEPS] Error:', err);
        res.status(500).json({ error: err.message });
    }
});

router.patch('/steps/:id', auth, async (req, res) => {
    try {
        const { completed } = req.body;
        const completed_at = completed ? new Date().toISOString() : null;
        await run('UPDATE consolidation_steps SET completed = ?, completed_at = ? WHERE id = ?',
            [completed ? 1 : 0, completed_at, req.params.id]);
        res.json({ success: true, completed_at });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Update Profile to auto-create steps
router.post('/profiles', auth, async (req, res) => {
    // Manual add using Insert
    try {
        const payload = { ...req.body };
        if (!payload.id) {
            payload.id = uuidv4();
        }

        const cols = Object.keys(payload).join(', ');
        const placeholders = Object.keys(payload).map(() => '?').join(', ');
        const vals = Object.values(payload);

        await run(`INSERT INTO profiles (${cols}) VALUES (${placeholders})`, vals);

        // Auto-create steps if it's a consolidation profile
        if (payload.consolidation_stage_id) {
            for (let i = 0; i < CONSOLIDATION_STEPS_TEMPLATE.length; i++) {
                const stepId = uuidv4();
                await run('INSERT INTO consolidation_steps (id, profile_id, step_name, step_order) VALUES (?, ?, ?, ?)',
                    [stepId, payload.id, CONSOLIDATION_STEPS_TEMPLATE[i], i]);
            }
        }

        res.json({ success: true, id: payload.id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.patch('/profiles/:id', auth, async (req, res) => {
    try {
        const updates = req.body;
        const cols = Object.keys(updates).map(k => `${k} = ?`).join(', ');
        const vals = [...Object.values(updates), req.params.id];

        await run(`UPDATE profiles SET ${cols} WHERE id = ?`, vals);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.delete('/profiles/:id', auth, async (req, res) => {
    try {
        const id = req.params.id;
        console.log(`[DELETE] Request for ID: ${id}`);
        // Manual Cascade Delete
        await run('DELETE FROM cell_attendance WHERE member_id = ?', [id]);

        // Nullify creator for tasks they created (to preserve those tasks if for others)
        await run('UPDATE tasks SET created_by_user_id = NULL WHERE created_by_user_id = ?', [id]);

        await run('DELETE FROM tasks WHERE related_member_id = ? OR assigned_to_id = ?', [id, id]);
        // Also nullify leaderships if necessary or just let them be (for now simple cascade)
        await run('UPDATE cells SET leader_id = NULL WHERE leader_id = ?', [id]);
        await run('UPDATE districts SET supervisor_id = NULL WHERE supervisor_id = ?', [id]);

        // Delete steps
        await run('DELETE FROM consolidation_steps WHERE profile_id = ?', [id]);

        const result = await run('DELETE FROM profiles WHERE id = ?', [id]);
        console.log(`[DELETE] Profiles deleted: ${result.changes}`);
        res.json({ success: true, changes: result.changes });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- CELLS ---
router.get('/cells', auth, async (req, res) => {
    try {
        const cells = await query('SELECT * FROM cells ORDER BY name');
        // Get counts
        for (const cell of cells) {
            const row = await get('SELECT count(*) as count FROM profiles WHERE cell_id = ? AND active = 1', [cell.id]);
            cell.profiles = [{ count: row.count }];
        }
        res.json(cells);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/cells', auth, async (req, res) => {
    try {
        const { name, leader_id, district_id, image_url, meeting_day } = req.body;
        const id = uuidv4();
        await run('INSERT INTO cells (id, name, leader_id, district_id, image_url, meeting_day) VALUES (?,?,?,?,?,?)',
            [id, name, leader_id, district_id, image_url, meeting_day]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.patch('/cells/:id', auth, async (req, res) => {
    try {
        const updates = req.body;
        const cols = Object.keys(updates).map(k => `${k} = ?`).join(', ');
        const vals = [...Object.values(updates), req.params.id];
        await run(`UPDATE cells SET ${cols} WHERE id = ?`, vals);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.delete('/cells/:id', auth, async (req, res) => {
    try {
        await run('DELETE FROM cells WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- DISTRICTS ---
router.get('/districts', auth, async (req, res) => {
    try {
        const districts = await query('SELECT * FROM districts ORDER BY name');
        for (const d of districts) {
            const row = await get('SELECT count(*) as count FROM cells WHERE district_id = ?', [d.id]);
            d.cells = [{ count: row.count }];
        }
        res.json(districts);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/districts', auth, async (req, res) => {
    try {
        const { name, supervisor_id, active, color } = req.body;
        const id = uuidv4();
        await run('INSERT INTO districts (id, name, supervisor_id, active, color) VALUES (?, ?, ?, ?, ?)',
            [id, name, supervisor_id, active, color]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.patch('/districts/:id', auth, async (req, res) => {
    try {
        const updates = req.body;
        const cols = Object.keys(updates).map(k => `${k} = ?`).join(', ');
        const vals = [...Object.values(updates), req.params.id];
        await run(`UPDATE districts SET ${cols} WHERE id = ?`, vals);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.delete('/districts/:id', auth, async (req, res) => {
    try {
        await run('DELETE FROM districts WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- TASKS ---
router.get('/tasks', auth, async (req, res) => {
    try {
        const { related_member_id, status } = req.query;
        let sql = 'SELECT * FROM tasks WHERE 1=1';
        const params = [];

        if (related_member_id) {
            sql += ' AND related_member_id = ?';
            params.push(related_member_id);
        }
        if (status) {
            sql += ' AND status = ?';
            params.push(status);
        }

        sql += ' ORDER BY due_date ASC';
        const tasks = await query(sql, params);
        res.json(tasks);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/tasks', auth, async (req, res) => {
    try {
        const task = req.body;
        const id = uuidv4();
        // Helper to map object to insert
        const keys = ['id', ...Object.keys(task)];
        const vals = [id, ...Object.values(task)];
        const placeholders = keys.map(() => '?').join(',');

        await run(`INSERT INTO tasks (${keys.join(',')}) VALUES (${placeholders})`, vals);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.patch('/tasks/:id', auth, async (req, res) => {
    try {
        const updates = req.body;
        const cols = Object.keys(updates).map(k => `${k} = ?`).join(', ');
        const vals = [...Object.values(updates), req.params.id];
        await run(`UPDATE tasks SET ${cols} WHERE id = ?`, vals);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.delete('/tasks/:id', auth, async (req, res) => {
    try {
        await run('DELETE FROM tasks WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- CONSOLIDATION STAGES ---
router.get('/consolidation_stages', auth, async (req, res) => {
    try {
        const stages = await query('SELECT * FROM consolidation_stages ORDER BY position');
        res.json(stages);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/consolidation_stages', auth, async (req, res) => {
    try {
        const { title, color, position } = req.body;
        const id = uuidv4();
        await run('INSERT INTO consolidation_stages (id, title, color, position) VALUES (?, ?, ?, ?)',
            [id, title, color, position]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.patch('/consolidation_stages/:id', auth, async (req, res) => {
    try {
        const updates = req.body;
        const cols = Object.keys(updates).map(k => `${k} = ?`).join(', ');
        const vals = [...Object.values(updates), req.params.id];
        await run(`UPDATE consolidation_stages SET ${cols} WHERE id = ?`, vals);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.delete('/consolidation_stages/:id', auth, async (req, res) => {
    try {
        await run('DELETE FROM consolidation_stages WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// --- ATTENDANCE ---
router.get('/attendance', auth, async (req, res) => {
    try {
        const { from, date, type, cell_id } = req.query;
        let sql = 'SELECT * FROM cell_attendance WHERE 1=1';
        const params = [];

        if (from) {
            sql += ' AND date >= ?';
            params.push(from);
        }
        if (date) {
            sql += ' AND date = ?';
            params.push(date);
        }
        if (type) {
            sql += ' AND type = ?';
            params.push(type);
        }
        if (cell_id) {
            sql += ' AND cell_id = ?';
            params.push(cell_id);
        }
        if (req.query.member_id) {
            sql += ' AND member_id = ?';
            params.push(req.query.member_id);
        }

        sql += ' ORDER BY date DESC';

        const records = await query(sql, params);
        res.json(records);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/attendance', auth, async (req, res) => {
    try {
        const payload = req.body;
        // Payload can be array (upsert) or single
        const items = Array.isArray(payload) ? payload : [payload];

        for (const item of items) {
            // Check for existing
            const existing = await get(
                'SELECT id FROM cell_attendance WHERE member_id = ? AND date = ? AND type = ?',
                [item.member_id, item.date, item.type]
            );

            if (existing) {
                // Fix: Update status and type/cell_id if needed
                await run('UPDATE cell_attendance SET status = ?, cell_id = ? WHERE id = ?',
                    [item.status, item.cell_id, existing.id]);
            } else {
                const id = uuidv4();
                await run(
                    'INSERT INTO cell_attendance (id, cell_id, member_id, date, status, type) VALUES (?, ?, ?, ?, ?, ?)',
                    [id, item.cell_id, item.member_id, item.date, item.status, item.type]
                );
            }
        }
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/attendance/delete', auth, async (req, res) => {
    try {
        const { ids } = req.body;
        if (!ids || !Array.isArray(ids)) return res.status(400).json({ error: "ids must be array" });

        const placeholders = ids.map(() => '?').join(',');
        await run(`DELETE FROM cell_attendance WHERE id IN (${placeholders})`, ids);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

export default router;
